package utils

object Revoked {
    var revoked : ArrayList<String> = ArrayList<String>()
}