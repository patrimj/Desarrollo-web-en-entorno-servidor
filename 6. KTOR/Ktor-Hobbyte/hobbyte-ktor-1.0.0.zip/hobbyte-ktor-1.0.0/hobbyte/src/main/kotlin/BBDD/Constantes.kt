object Constantes {
    val servidor = "localhost"
    val puerto = 3306

    var bbdd = "hobbyte"
    var usuario = "root"
    var passwd = ""

    var TablaUsuarios = "users"
    var TablaCasillas = "casillas"
    var TablaPartidas = "partidas"
    var TablaPruebas = "pruebas"
    var TablaHeroes = "heroes"

}