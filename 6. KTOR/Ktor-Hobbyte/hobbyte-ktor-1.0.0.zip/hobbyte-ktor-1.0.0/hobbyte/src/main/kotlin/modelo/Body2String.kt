package modelo

import kotlinx.serialization.Serializable

@Serializable
data class Body2String( var valores:Map<String,String>)
